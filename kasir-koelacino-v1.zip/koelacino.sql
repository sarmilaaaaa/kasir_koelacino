-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2022 at 09:03 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `koelacino`
--

-- --------------------------------------------------------

--
-- Table structure for table `kasir`
--

CREATE TABLE `kasir` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kasir`
--

INSERT INTO `kasir` (`id`, `username`, `password`, `nama`) VALUES
(1, 'eko', '$2y$10$1tFNt/uXg511B8eODY3dEe4eVwByxqQz6UtdlMugBWK0FJs4V34da', 'Eko Mujianto'),
(5, 'jeje', '$2y$10$Ca6lqzrORf1EcGqUdqprpucMh2Vaqm4Ronu2RnG8UEIdluh44ecoq', 'Jamilah'),
(6, 'mila', '$2y$10$5mK/RPD87y1plK68Zxrv6.1qvA.nr7P6pfmceSeFLthagBtXI3YE.', 'Sarmila');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `harga` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `jenis` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `nama`, `harga`, `gambar`, `jenis`) VALUES
(2, 'Red Velvet', 18000, '63add65540db4.jpeg', 'Minuman'),
(3, 'Es Coklat', 20000, '63add6bc29e93.jpeg', 'Minuman'),
(4, 'Susu Regal', 18000, '63add6cce8ccc.jpeg', 'Minuman'),
(5, 'Pandan Regal', 22000, '63add6d74dd83.jpeg', 'Minuman'),
(6, 'Signature Koelacino', 15000, '63add6f946101.jpeg', 'Minuman'),
(7, 'Lecy Tea', 20000, '63add71681cea.jpeg', 'Minuman'),
(8, 'Banana Oreo', 22000, '63add81724db3.jpeg', 'Minuman'),
(9, 'Mie Goreng Koelacino', 15000, '63add84566b8b.jpeg', 'Makanan'),
(10, 'Nasi Sambal Matah', 20000, '63add856411f3.jpeg', 'Makanan'),
(11, 'Mix Sampler', 15000, '63add868836da.jpeg', 'Makanan'),
(12, 'Cireng', 15000, '63add8779665d.jpeg', 'Makanan');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `id` int(11) NOT NULL,
  `username_kasir` varchar(255) NOT NULL,
  `id_menu` int(11) NOT NULL,
  `jenis_minuman` varchar(255) DEFAULT NULL,
  `jumlah` int(11) NOT NULL,
  `jenis_pembayaran` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kasir`
--
ALTER TABLE `kasir`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kasir`
--
ALTER TABLE `kasir`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
