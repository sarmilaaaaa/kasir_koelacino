<?php 
require 'functions.php';

function tambah($id) {
    global $conn;
    global $username;

    // cek 
    $cek = "SELECT * FROM menu where id = $id";
    $prosescek= query($cek)[0];

    if ($prosescek['jenis'] == "Minuman") { 
        echo "<script>window.location.href='proses.php?id=$id&&username=$username&&minuman=true'</script>";
        exit;
    } else {
    	echo "<script>window.location.href='proses.php?id=$id&&username=$username&&makanan=true'</script>";
        exit;
    }
}

$id = $_GET["id"];
$username = $_GET["username"];
if (tambah($id) > 0 ) {
	echo "
		<script>
			alert('Data berhasil dihapus!');
			document.location.href = 'fitur.php';
		</script>
	";
    } else {
	echo "
		<script>
			alert('Data gagal dihapus!');
			document.location.href = 'fitur.php';
		</script>
	";
	}
 ?>