-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2023 at 02:10 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `koelacino`
--

-- --------------------------------------------------------

--
-- Table structure for table `kasir`
--

CREATE TABLE `kasir` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kasir`
--

INSERT INTO `kasir` (`id`, `username`, `password`, `nama`) VALUES
(1, 'eko', '$2y$10$1tFNt/uXg511B8eODY3dEe4eVwByxqQz6UtdlMugBWK0FJs4V34da', 'Eko Mujianto'),
(5, 'jeje', '$2y$10$Ca6lqzrORf1EcGqUdqprpucMh2Vaqm4Ronu2RnG8UEIdluh44ecoq', 'Jamilah'),
(6, 'mila', '$2y$10$5mK/RPD87y1plK68Zxrv6.1qvA.nr7P6pfmceSeFLthagBtXI3YE.', 'Sarmila');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `harga` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `jenis` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `nama`, `harga`, `gambar`, `jenis`) VALUES
(2, 'Red Velvet', 18000, '63add65540db4.jpeg', 'Minuman'),
(3, 'Es Coklat', 20000, '63add6bc29e93.jpeg', 'Minuman'),
(4, 'Susu Regal', 18000, '63add6cce8ccc.jpeg', 'Minuman'),
(5, 'Pandan Regal', 22000, '63add6d74dd83.jpeg', 'Minuman'),
(6, 'Signature Koelacino', 12000, '63add6f946101.jpeg', 'Minuman'),
(7, 'Lecy Tea', 20000, '63add71681cea.jpeg', 'Minuman'),
(9, 'Mie Goreng Koelacinoo', 25000, '63add84566b8b.jpeg', 'Makanan'),
(17, 'Cireng', 25000, '63bc3c5dd21b4.jpeg', 'Makanan'),
(18, 'Nasi Sambal Matah', 24000, '63bc515539edb.jpeg', 'Makanan');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `id` int(11) NOT NULL,
  `username_kasir` varchar(255) NOT NULL,
  `id_menu` int(11) NOT NULL,
  `jenis_minuman` varchar(255) DEFAULT NULL,
  `harga` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `jenis_pembayaran` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `kode_pesanan` varchar(255) DEFAULT NULL,
  `waktu_pesan` varchar(255) DEFAULT NULL,
  `bayar` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id`, `username_kasir`, `id_menu`, `jenis_minuman`, `harga`, `jumlah`, `jenis_pembayaran`, `status`, `nama`, `kode_pesanan`, `waktu_pesan`, `bayar`, `tanggal`) VALUES
(79, 'eko', 7, 'Dingin', 20000, 1, 'Tunai', 'Sukses', NULL, '93EKO100123015201', '10 January 2023 01:52', 100000, '2023-01-10'),
(80, 'eko', 17, NULL, 25000, 2, 'Tunai', 'Sukses', NULL, '93EKO100123015201', '10 January 2023 01:52', 100000, '2023-01-10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kasir`
--
ALTER TABLE `kasir`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kasir`
--
ALTER TABLE `kasir`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
