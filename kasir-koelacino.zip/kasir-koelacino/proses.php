<?php 

session_start();
require 'functions.php';


if (!isset($_SESSION["user"])) {
    echo "<script>
    window.location.href='login.php';
  </script>";
    exit;
}


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'link.php'; ?>
  </head>
  <body>

    <?php  if (isset($_GET['checkout'])) : ?>

      <script type='text/javascript'>
          $(document).ready(function(){
            $('#checkoutModal').modal('show');
          });

      </script>

    <?php endif; ?>

      <?php 


        function addMakanan($data) {
            global $conn;

            // htmlspecialchars berfungsi untuk tidak menjalankan script
            $username_kasir = htmlspecialchars($data["username_kasir"]);
            $id_menu = htmlspecialchars($data["id_menu"]);
            $jumlah = htmlspecialchars($data["jumlah"]);
            $tanggal = htmlspecialchars($data["tanggal"]);
            $harga = htmlspecialchars($data["harga"]);


            mysqli_query($conn, "INSERT INTO pesanan VALUES(NULl, '$username_kasir', '$id_menu', NULL, '$harga', '$jumlah', NULL, NULL, NULL, NULL, NULL, NULL, '$tanggal')");
            return mysqli_affected_rows($conn);
        }

        if (isset($_POST["add"])) {
          
          if (addMakanan($_POST) > 0 ) {
             echo "
              <script>
                const Toast = Swal.mixin({
                  toast: true,
                  position: 'top-end',
                  showConfirmButton: false,
                  timer: 2000,
                  timerProgressBar: true
                })

                Toast.fire({
                  icon: 'success',
                  title: 'Berhasil Menambah Pesanan'
                })

                window.location.href='proses.php?success=true'
              </script> " ;
          } else {
            echo mysqli_error($conn);
          }

        } 


       ?>

       <?php 


        function addMinuman($data) {
            global $conn;

            // htmlspecialchars berfungsi untuk tidak menjalankan script
            $username_kasir = htmlspecialchars($data["username_kasir"]);
            $id_menu = htmlspecialchars($data["id_menu"]);
            $jumlah = htmlspecialchars($data["jumlah"]);
            $harga = htmlspecialchars($data["harga"]);
            $tanggal = htmlspecialchars($data["tanggal"]);

            if (isset($data["jenis_minuman"])) {

              $jenis_minuman = htmlspecialchars($data["jenis_minuman"]);

              if ($jenis_minuman == NULL OR $jenis_minuman == "") {
                  echo "<script>window.location.href='proses.php?id=$id_menu&jenis_minuman=true&minuman=true&harga=$harga&username=$username_kasir'</script>";
                  exit;
              }

              mysqli_query($conn, "INSERT INTO pesanan VALUES(NULl, '$username_kasir', '$id_menu', '$jenis_minuman', '$harga', '$jumlah', NULL, NULL, NULL, NULL, NULL, NULL,  '$tanggal')");
              return mysqli_affected_rows($conn);

            } else {
              echo "<script>window.location.href='proses.php?id=$id_menu&jenis_minuman=true&minuman=true&harga=$harga&username=$username_kasir'</script>";
              exit;
            }

            
        }

        if (isset($_POST["addMinuman"])) {
          
          if (addMinuman($_POST) > 0 ) {
             echo "
              <script>
                const Toast = Swal.mixin({
                  toast: true,
                  position: 'top-end',
                  showConfirmButton: false,
                  timer: 2000,
                  timerProgressBar: true
                })

                Toast.fire({
                  icon: 'success',
                  title: 'Berhasil Menambah Pesanan'
                })

                window.location.href='proses.php?success=true'
              </script> " ;
          } else {
            echo mysqli_error($conn);
          }

        } 


       ?>

       <?php 

        $query = query("SELECT MAX(id) id FROM pesanan LIMIT 1")[0]; 
        $id = $query['id'] + 10 + rand(2, 5); 
        $uniq_id = $id; 
        $kasir = strtoupper($_SESSION['username']); 
        $zona_waktu = time() + (60 * 60 * 8); 
        $waktu = gmdate('dmyHis', $zona_waktu); 

        $waktu_pesanan = gmdate('d F Y H:i', $zona_waktu);

        $kode = $uniq_id . $kasir . $waktu; 
        $kode_pesanan = strtoupper($kode); 


        function checkout($data) {
            global $conn;

            global $waktu_pesanan; 
            global $kode_pesanan; 
            

            // htmlspecialchars berfungsi untuk tidak menjalankan script
            $jenis_pembayaran = htmlspecialchars($data["jenis_pembayaran"]);
            

            if ($jenis_pembayaran != "Tunai") {

              $nama = htmlspecialchars($data["nama"]);

              if (isset($data["bayar"])) {

                $bayar = htmlspecialchars($data["bayar"]);
                mysqli_query($conn, "UPDATE pesanan SET jenis_pembayaran = '$jenis_pembayaran', status = 'Sukses', nama = '$nama', kode_pesanan = '$kode_pesanan', waktu_pesan = '$waktu_pesanan', bayar = $bayar WHERE jenis_pembayaran IS NULL");
              } 

              else {
              mysqli_query($conn, "UPDATE pesanan SET jenis_pembayaran = '$jenis_pembayaran', status = 'Sukses', nama = '$nama', kode_pesanan = '$kode_pesanan', waktu_pesan = '$waktu_pesanan' WHERE jenis_pembayaran IS NULL");
              }

            } 

            else {

              if (isset($data["bayar"])) {
                $bayar = htmlspecialchars($data["bayar"]);
                mysqli_query($conn, "UPDATE pesanan SET jenis_pembayaran = '$jenis_pembayaran', status = 'Sukses', kode_pesanan = '$kode_pesanan', waktu_pesan = '$waktu_pesanan', bayar = $bayar WHERE jenis_pembayaran IS NULL");
              } 

              else {

              mysqli_query($conn, "UPDATE pesanan SET jenis_pembayaran = '$jenis_pembayaran', status = 'Sukses', kode_pesanan = '$kode_pesanan', waktu_pesan = '$waktu_pesanan' WHERE jenis_pembayaran IS NULL");
              }

            }

            return mysqli_affected_rows($conn);
        }

        if (isset($_POST["checkout"])) {
          
          if (checkout($_POST) > 0 ) {
             header("Location: cetak-pesanan.php?kode_pesanan=$kode_pesanan");
             exit;
          } else {
            echo mysqli_error($conn);
          }

        } 


       ?>

       <?php if (isset($_GET['success'])) : ?>
        <script>
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 2000,
            timerProgressBar: true
          })

          Toast.fire({
            icon: 'success',
            title: 'Berhasil Menambah Pesanan'
          })
        </script> 
        <?php endif; ?>

        <?php if (isset($_GET['done'])) : ?>
        <script>
          const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 2000,
            timerProgressBar: true
          })

          Toast.fire({
            icon: 'success',
            title: 'Berhasil Checkout Pesanan'
          })
        </script> 
        <?php endif; ?>

        <script>
          function errorCheckout() {
            const Toast = Swal.mixin({
              toast: true,
              position: 'middle',
              showConfirmButton: false,
              timer: 2000
            })

            Toast.fire({
              icon: 'warning',
              title: 'Belum Ada Pesanan!'
            })
          }
        </script> 
    <!-- ======== sidebar-nav start =========== -->
    <?php include 'sidebar.php'; ?>
    <!-- ======== sidebar-nav end =========== -->

    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">
      <!-- ========== header start ========== -->
      <header class="header">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-5 col-md-5 col-6">
              <div class="header-left d-flex align-items-center">
                <div class="menu-toggle-btn mr-20">
                  <button
                    id="menu-toggle"
                    class="main-btn primary-btn btn-hover"
                  >
                    <i class="lni lni-chevron-left me-2"></i> Menu
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <!-- ========== header end ========== -->

      <!-- ========== tab components start ========== -->
      <section class="tab-components">
        <div class="container-fluid">
          <!-- ========== title-wrapper start ========== -->
          <div class="title-wrapper pt-30">
            <div class="row align-items-center">
              <div class="col-md-6">
                <div class="title mb-30">
                  <h2>Tambah Pesanan</h2>
                  <br>
                  <br>
                  <!-- Button trigger modal -->
                  <?php $jumlah_pesanan = query("SELECT COUNT(id) as total FROM pesanan WHERE status IS NULL")[0]; ?>

                  <?php if ($jumlah_pesanan['total'] <= 0) : ?>

                    <button class="btn btn-primary" onclick="return errorCheckout();">
                    Checkout Pesanan ( <b><?= $jumlah_pesanan['total']; ?></b> )
                  </button>

                  <?php else: ?>

                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#checkoutModal">
                    Checkout Pesanan ( <b><?= $jumlah_pesanan['total']; ?></b> )
                  </button>

                  <?php endif; ?>

                  <!-- Modal -->
                  <div class="modal fade" id="checkoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Checkout Pesanan ( <b><?= $jumlah_pesanan['total']; ?></b> )</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form action="" method="post">
                        <div class="modal-body">
                          <?php $pesanan = mysqli_query($conn, "SELECT * FROM pesanan WHERE status IS NULL"); ?>
                          <?php foreach ($pesanan as $p) :  ?>
                          <div class="row d-flex justify-content-between mb-3">
                            <div class="col-6">
                              <?php $id_menu = $p['id_menu'] ?>
                              <?php $menu = query("SELECT * FROM menu WHERE id = $id_menu")[0]; ?>
                              <?=$menu['nama']?>
                            </div>
                            <div class="col-4">
                              x <?=$p['jumlah']?>
                            </div>
                            <div class="col-2">
                              <a href="hapus-proses.php?id=<?= $p['id']; ?>" class="badge bg-danger text-white">Batal</a>
                            </div>
                          </div>
                          <?php $total = 0; ?>
                          <?php error_reporting(0) ?>
                          <?php $total = $p['harga'] * $p['jumlah'] ?>
                          <?php $total_all += $total; ?>
                          <?php endforeach; ?>
                          <div class="my-3" style="border-bottom: 1px dotted black;"></div>
                          <p>Total Pembayaran : <b>Rp<?= number_format($total_all,0,',','.'); ?></b></p>
                          <div class="my-3" style="border-bottom: 1px dotted black;"></div>
                          <div class="input-style-1 my-3">
                            <label>Pilih Jenis Pembayaran</label>
                            <select name="jenis_pembayaran" id="jenis_pembayaran" class="form-control" required>
                              <option value="=">Pilih</option>
                              <option value="Tunai">Tunai</option>
                              <option value="QRIS">QRIS</option>
                              <option value="Debit BCA">Debit BCA</option>
                              <option value="Debit BRI">Debit BRI</option>
                              <option value="Debit BNI">Debit BNI</option>
                            </select>
                          </div>

                          <div id="ajaxNama">
                          
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" name="checkout" class="w-100 btn btn-primary">Proses Checkout</button>
                        </div>
                        <form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- end col -->
              <div class="col-md-6">
                <div class="breadcrumb-wrapper mb-30">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a href="#0">Koelacino</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Tambah Pesanan
                      </li>
                    </ol>
                  </nav>
                </div>
              </div>
              <!-- end col -->
            </div>
            <!-- end row -->
          </div>
          <!-- ========== title-wrapper end ========== -->

          <!-- ========== form-elements-wrapper start ========== -->
          <div class="form-elements-wrapper">
            <div class="row">
              <div class="col">
                <!-- input style start -->
                <div class="card-style mb-30">
                  <div class="row">
                    <?php $menu = mysqli_query($conn, "SELECT * FROM menu"); ?>
                      <div class="row justify-content-start" style="flex-wrap: wrap;">
                          <?php foreach ($menu as $key) : ?>
                          <div class="col-3">
                            <a  href="tambah.php?id=<?= $key['id']; ?>&&username=<?= $_SESSION['username']; ?>">
                              <div class=" my-3" style="background-color:#EFEFEF;border-radius: 8px;box-shadow: 2px 2px 10px lightgrey;">
                                <img class="m-4" src="foto/<?= $key['gambar']; ?>" width="150" alt="" />
                                <p style="position: relative;bottom: 10px;left:20px">
                                  <span class="status-btn success-btn w-80 text-dark">
                                    <small><?= $key['nama']; ?></small>
                                  </span>
                                </p>
                              </div>
                            </a>
                          </div>

                          <!-- Button trigger modal -->
                        


                          <?php endforeach; ?>
                      </div>
                  </div>
                </div>
                <!-- end card -->
                <!-- ======= input style end ======= -->

                <!-- Modal -->
                          <?php if (isset($_GET['minuman'])) : ?>
                            <script>
                                $(document).ready(function(){
                                    $("#confirmModal").modal('show');
                                });
                            </script>


                          <div class="modal fade" id="confirmModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="staticBackdropLabel">Konfirmasi</h5>
                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="" method="post">
                                <div class="modal-body">
                                  <?php $tanggal = gmdate('y-m-d', $zona_waktu);  ?> 
                                  <input type="hidden" name="tanggal" value="<?= $tanggal; ?>">
                                  <input type="hidden" name="id_menu" value="<?= $_GET['id']; ?>">
                                  <input type="hidden" name="harga" value="<?= $_GET['harga']; ?>">
                                  <input type="hidden" name="username_kasir" value="<?= $_GET['username']; ?>">

                                  <div class="row">
                                    <div class="col">
                                      <input type="number" name="jumlah" class="form-control" placeholder="Masukkan Jumlah Pesanan" required>
                                    </div>
                                  </div>

                                  <div class="row mt-4">
                                    <div class="col">
                                      <div class="form-check radio-style radio-warning mb-20">
                                          <input
                                            class="form-check-input"
                                            type="radio"
                                            value="Dingin"
                                            name="jenis_minuman"
                                          />
                                          <label class="form-check-label">
                                            Dingin</label
                                          >
                                        </div>
                                    </div>
                                    <div class="col">
                                      <div class="form-check radio-style radio-danger mb-20">
                                          <input
                                            class="form-check-input"
                                            type="radio"
                                            value="Panas"
                                            name="jenis_minuman"
                                          />
                                          <label class="form-check-label">
                                            Panas</label
                                          >
                                        </div>
                                    </div>
                                  </div>
                                  <?php if (isset($_GET['jenis_minuman'])) : ?>
                                  <div class="alert alert-danger">
                                    <p>Mohon masukkan jenis minuman! <b>Dingin atau Panas</b></p>
                                  </div>
                                  <?php endif; ?>
                                </div>
                                <div class="modal-footer">
                                  <button type="submit" name="addMinuman" class="w-100 btn btn-primary">Tambah</button>
                                </div>
                                </form>
                              </div>
                            </div>
                          </div>
                          <?php endif; ?>

                          <?php if (isset($_GET['makanan'])) : ?>
                            <script>
                                $(document).ready(function(){
                                    $("#confirmModal2").modal('show');
                                });
                            </script>


                          <div class="modal fade" id="confirmModal2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="staticBackdropLabel">Konfirmasi</h5>
                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="" method="post">
                                <div class="modal-body">
                                  <?php $tanggal = gmdate('y-m-d', $zona_waktu);  ?> 
                                  <input type="hidden" name="tanggal" value="<?= $tanggal; ?>">
                                  <input type="hidden" name="id_menu" value="<?= $_GET['id']; ?>">
                                  <input type="hidden" name="harga" value="<?= $_GET['harga']; ?>">
                                  <input type="hidden" name="username_kasir" value="<?= $_GET['username']; ?>">

                                  <div class="row">
                                    <div class="col">
                                      <input type="number" name="jumlah" class="form-control" placeholder="Masukkan Jumlah Pesanan" required>
                                    </div>
                                  </div>
                                </div>
                                <div class="modal-footer">
                                  <button type="submit" name="add" class="w-100 btn btn-primary">Tambah</button>
                                </div>
                                </form>
                              </div>
                            </div>
                          </div>
                          <?php endif; ?>




              </div>
              <!-- end col -->
            </div>
            <!-- end row -->
          </div>
          <!-- ========== form-elements-wrapper end ========== -->
        </div>
        <!-- end container -->
      </section>
      <!-- ========== tab components end ========== -->

      <!-- ========== footer start =========== -->
      <footer class="footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-6 order-last order-md-first">
              <div class="copyright text-center text-md-start">
                <p class="text-sm">
                  Designed and Developed by
                  <a
                    href="https://plainadmin.com"
                    rel="nofollow"
                    target="_blank"
                  >
                    PlainAdmin
                  </a>
                </p>
              </div>
            </div>
            <!-- end col-->
            <div class="col-md-6">
              <div
                class="
                  terms
                  d-flex
                  justify-content-center justify-content-md-end
                "
              >
                <a href="#0" class="text-sm">Term & Conditions</a>
                <a href="#0" class="text-sm ml-15">Privacy & Policy</a>
              </div>
            </div>
          </div>
          <!-- end row -->
        </div>
        <!-- end container -->
      </footer>
      <!-- ========== footer end =========== -->
    </main>
    <!-- ======== main-wrapper end =========== -->

    <!-- ========= All Javascript files linkup ======== -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/Chart.min.js"></script>
    <script src="assets/js/dynamic-pie-chart.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/fullcalendar.js"></script>
    <script src="assets/js/jvectormap.min.js"></script>
    <script src="assets/js/world-merc.js"></script>
    <script src="assets/js/polyfill.js"></script>
    <script src="assets/js/main.js"></script>

    <script src="ajax/index.js"></script>
  </body>
</html>
