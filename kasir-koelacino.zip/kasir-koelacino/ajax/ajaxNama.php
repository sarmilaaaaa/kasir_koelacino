<?php 

session_start();
require '../functions.php';


if (!isset($_SESSION["user"])) {
    echo "<script>
    window.location.href='login.php';
  </script>";
    exit;
}


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include '../link.php'; ?>
  </head>
  <body>


    <div id="ajaxNama">
      <?php if (isset($_GET['jenis_pembayaran'])) : ?>
        <?php if ($_GET['jenis_pembayaran'] != "Tunai") : ?>
          <label class="form-label">Masukkan Nama Pengirim</label>
          <input type="text" class="form-control" name="nama" placeholder="...." required>
        <?php endif; ?>

        <?php if ($_GET['jenis_pembayaran'] == "Tunai") : ?>
          <p>Jumlah Bayar : </p>
          <input type="number" placeholder="Masukkan Jumlah Uang Customer" class="form-control" name="bayar" required>
        <?php endif; ?>
      <?php endif; ?>
    </div>

                        

    <!-- ========= All Javascript files linkup ======== -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/Chart.min.js"></script>
    <script src="../assets/js/dynamic-pie-chart.js"></script>
    <script src="../assets/js/moment.min.js"></script>
    <script src="../assets/js/fullcalendar.js"></script>
    <script src="../assets/js/jvectormap.min.js"></script>
    <script src="../assets/js/world-merc.js"></script>
    <script src="../assets/js/polyfill.js"></script>
    <script src="../assets/js/main.js"></script>
  </body>
</html>
