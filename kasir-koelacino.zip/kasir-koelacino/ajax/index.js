// ambil elemen2 yang dibutuhkan
var jenis_pembayaran = document.getElementById('jenis_pembayaran');
var ajaxNama = document.getElementById('ajaxNama');


	// tambahkan event ketika jenis_pembayaran ditulis
	$('#jenis_pembayaran').change(function(){
	// untuk select option gunakan 'change'

	// buat object ajax
	var xhr = new XMLHttpRequest();	

	// cek kesiapan ajax
	xhr.onreadystatechange = function() {
		if ( xhr.readyState == 4 && xhr.status == 200 ) {
			ajaxNama.innerHTML = xhr.responseText;
		}
	}

	// eksekusi ajax
	xhr.open('GET', 'ajax/ajaxNama.php?jenis_pembayaran=' + jenis_pembayaran.value, true);
	xhr.send();

	});




