<?php 
session_start();
include '../functions.php';

if (!isset($_SESSION["user"])) {
    echo "<script>
    window.location.href='login.php';
  </script>";
    exit;
}

$tanggalx = $_GET["tanggalx"];


$query = "SELECT * FROM pesanan
      WHERE
      tanggal = '$tanggalx' AND status IS NOT NULL GROUP BY kode_pesanan
        ";
$pesananx = mysqli_query($conn, $query);

if (mysqli_num_rows($pesananx) <= 0){
  $nf = true;
}



 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include '../link.php'; ?>
    <style>
      th,td {
        text-align: center !important;
      }
    </style>
  </head>
  <body>

    

          <div id="ajaxPesanan">

            <?php if (isset($nf)) :  ?>

            <div class="alert alert-danger bg-danger">
              <center>
                <h4 class="text-white">
                  Maaf, tidak ditemukan transaksi pada tanggal  : <b><?= date("d F Y",strtotime($tanggalx)); ?></b>
                </h4>
              </center>
            </div>

          <?php endif; ?>
     
              <?php foreach ($pesananx as $p) : ?>
              <div class="card-style mb-30">
                <div
                  class="
                    title
                    d-flex
                    flex-wrap
                    align-items-center
                    justify-content-between
                  "
                >
                  <div class="left">
                    <h6 class="text-medium mb-30">
                      <span class="badge bg-info fs-6">Kode Pesanan : <u><?= $p['kode_pesanan']; ?></u></span>
                      <a href="cetak-pesanan.php?kode_pesanan=<?= $p['kode_pesanan']; ?>"><span class="badge bg-warning fs-6"><i class="fas fa-download"></i> Cetak Struk</span></a>
                    </h6>
                  </div>
                  <div class="right">
                    <div class="select-style-1">
                      
                    </div>
                    <!-- end select -->
                  </div>
                </div>
                <!-- End Title -->
                <div class="table-responsive">
                  <table class="table top-selling-table">
                    <thead>
                      <tr>
                        <th>
                          <h6 class="text-sm text-medium">Produk</h6>
                        </th>
                        <th class="min-width">
                          <h6 class="text-sm text-medium">
                            Jumlah                          
                          </h6>
                        </th>
                        <th class="min-width">
                          <h6 class="text-sm text-medium">
                            Harga 
                          </h6>
                        </th>
                        <th class="min-width">
                          <h6 class="text-sm text-medium">
                            Total 
                          </h6>
                        </th>
                        <th>
                          <h6 class="text-sm text-medium">
                            Metode Pembayaran 
                          </h6>
                        </th>
                        <th>
                          <h6 class="text-sm text-medium">
                            Kasir
                          </h6>
                        </th>
                        <th>
                          <h6 class="text-sm text-medium">
                            Status 
                          </h6>
                        </th>
                      </tr>
                    </thead>
                    <?php $kode_pesanan = $p['kode_pesanan']; ?>
                    <?php $detail_pesanan = mysqli_query($conn, "SELECT * FROM pesanan WHERE tanggal = '$tanggalx' AND status IS NOT NULL AND kode_pesanan = '$kode_pesanan'"); ?>
                    <?php foreach ($detail_pesanan as $detail) : ?>
                    <tbody>
                      <tr>
                        <td>
                          <div class="product">
                              <?php $id_menu = $detail['id_menu'] ?>
                              <?php $menu = query("SELECT * FROM menu WHERE id = $id_menu")[0]; ?>
                            <p class="text-sm"><?= $menu['nama']; ?> <b><i><?= $detail['jenis_minuman']; ?></i></b></p>
                          </div>
                        </td>
                        <td>
                          <p class="text-sm">x <?= $detail['jumlah']; ?></p>
                        </td>
                        <td>
                          <p class="text-sm">Rp<?= number_format($menu['harga'],0,',','.'); ?></p>
                        </td>
                        <td>
                          <p class="text-sm">
                            <?php $total = $menu['harga'] * $detail['jumlah']; ?>
                              Rp<?= number_format($total,0,',','.'); ?>
                            </p>
                        </td>
                        <td>
                          <p class="text-sm"><?= $detail['jenis_pembayaran']; ?></p>
                        </td>
                        <td>
                          <p class="text-sm"><?= $detail['username_kasir']; ?></p>
                        </td>
                        <td>
                          <span class="status-btn success-btn"><?= $detail['status']; ?></span>
                        </td>
                      </tr>
                    </tbody>
                    <?php endforeach; ?>
                  </table>
                  <!-- End Table -->
                </div>
              </div>
              <?php endforeach; ?>

        </div>


    <!-- ========= All Javascript files linkup ======== -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/Chart.min.js"></script>
    <script src="assets/js/dynamic-pie-chart.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/fullcalendar.js"></script>
    <script src="assets/js/jvectormap.min.js"></script>
    <script src="assets/js/world-merc.js"></script>
    <script src="assets/js/polyfill.js"></script>
    <script src="assets/js/main.js"></script>

  </body>
</html>
