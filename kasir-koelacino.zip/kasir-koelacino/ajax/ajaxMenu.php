<?php 

session_start();
require '../functions.php';


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <script>
         $(document).ready(function() {

         $("#form").hide();

         $("#btn-show").click(function() {
           $("#form").show();
         })

         $("#btn-hide").click(function() {
           $("#form").hide();
         })

       });
    </script>
  </head>
  <body>
   



                <div id="ajaxMenu">
            <div class="card p-3">
              <table class="table">
                <thead>
                  <tr>
                    <th>Jenis</th>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Gambar</th>
                    <th colspan="2">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $keyword = $_GET['keyword'];
                      $menu = mysqli_query($conn, "SELECT * FROM menu WHERE nama LIKE '%$keyword%' ORDER BY id DESC");  ?>
                    <?php foreach($menu as $m) : ?>
                    <tr>
                      <td><?= $m['jenis']; ?></td>
                      <td><?= $m['nama']; ?></td>
                      <td>Rp<?= number_format($m['harga'],0,',','.'); ?></td>
                      <td><img src="../foto/<?= $m['gambar']; ?>" width="100"></td>
                      <td>
                        <a href="index.php?edit=true&id=<?= $m['id']; ?>" class="btn btn-warning text-white">
                          <i class="fas fa-edit"></i> Edit
                        </a>
                      </td>
                      <td>
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#delAjax<?= $m['id']; ?>">
                          <i class="fas fa-trash-alt"></i> Delete
                        </button>
                      </td>
                    </tr>
                </tbody>

                <!-- Delete Modal -->
                <div class="modal fade" id="delAjax<?= $m['id']; ?>" tabindex="-1" aria-labelledby="delAjax<?= $m['id']; ?>" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="delAjax<?= $m['id']; ?>">Konfirmasi Delete Menu</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">

                        <center>
                          <p>Yakin menghapus menu secara permanen?</p>
                          <br>
                        </center>

                        <form action="" method="post" enctype="multipart/form-data">

                            <a href="hapus-menu.php?id=<?= $m['id']; ?>" class="btn btn-danger w-100 text-white">Ya, Hapus Permanen</a>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>

              <?php endforeach; ?>


              </table>
            </div>
          </div>

           <?php $total_menu = mysqli_num_rows($menu); ?>
            <?php if ($total_menu == 0) : ?>
              <div class="alert bg-warning text-white mt-3">
                <span>
                  Produk dengan keyword <b>'<?= $keyword; ?></b>' tidak ditemukan.
                </span>
              </div>
            <?php endif; ?>

        

    <!-- ========= All Javascript files linkup ======== -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/Chart.min.js"></script>
    <script src="../assets/js/dynamic-pie-chart.js"></script>
    <script src="../assets/js/moment.min.js"></script>
    <script src="../assets/js/fullcalendar.js"></script>
    <script src="../assets/js/jvectormap.min.js"></script>
    <script src="../assets/js/world-merc.js"></script>
    <script src="../assets/js/polyfill.js"></script>
    <script src="../assets/js/main.js"></script>


  </body>
</html>