<?php 
session_start();
include 'functions.php';

if (!isset($_SESSION["user"])) {
    echo "<script>
    window.location.href='login.php';
  </script>";
    exit;
}

$kode_pesanan = $_GET['kode_pesanan'];

$pesanan = query("SELECT * FROM pesanan WHERE kode_pesanan = '$kode_pesanan'")[0];



 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'link.php'; ?>
    <style>
      * {
        font-size: 0.8rem !important;
        font-weight: 800;
        padding: 0;
        margin: 0;
      }
    </style>
  </head>
  <body>

      <center>
        <span>Koelacino <br>
        pameracoffee@gmail.com</span>
        <div style="margin-top:5px;margin-bottom:5px;border-bottom: 0.5px dotted grey;"></div>
      </center>

      <div style="display:flex;" class="mb-1">
        <div style="flex-grow: 3;" style="margin-bottom:5px;">
          Kode Pesanan : <br>
          <b><?= $kode_pesanan; ?></b>
          <br>
        </div>
      </div>

      <div style="display:flex;" class="mb-1">
        <div style="flex-grow: 3;" style="margin-bottom:5px;">
          Waktu : <br>
          <b><?= $pesanan['waktu_pesan']; ?></b>
          <br>
        </div>
      </div>

      <div style="display:flex;">
        <div style="flex-grow: 1;">
          Kasir : <br>

          <?php $username = $pesanan['username_kasir']; ?>
          <?php $user = query("SELECT * FROM kasir WHERE username = '$username'")[0]; ?>
          <b><?= $user['nama']; ?></b>
        </div>
      </div>

      <div style="margin-bottom:5px;margin-top:5px;border-bottom: 0.5px dotted grey;"></div>

      <table class="">
        <?php $detail_pesanan = mysqli_query($conn, "SELECT * FROM pesanan WHERE status IS NOT NULL AND kode_pesanan = '$kode_pesanan'"); ?>
        <?php foreach ($detail_pesanan as $detail) : ?>
          
          <div style="margin-bottom:5px;margin-top:5px;">
            
            <div style="display:flex;">
              <div style="flex-grow: 1;">
                  <?php $id_menu = $detail['id_menu'] ?>
                  <?php $menu = query("SELECT * FROM menu WHERE id = $id_menu")[0]; ?>
                  <?= $menu['nama']; ?>  <i><?= $detail['jenis_minuman']; ?> x <?= $detail['jumlah']; ?></i>
              </div>
            </div>

            <div style="display:flex;">
              <div style="flex-grow: 1;">
                <b>@Rp<?= number_format($detail['harga'],0,',','.'); ?></b>
              </div>
            </div>

          </div>

          <?php error_reporting(0); ?>
          <?php $total_all += $detail['jumlah'] * $detail['harga']; ?>
        <?php endforeach; ?>
      </table>

      <div style="margin-bottom:5px;margin-top:5px;border-bottom: 0.5px dotted grey;"></div>

      <div style="display:flex;">
        <div style="flex-grow: 1;">
         Total Tagihan
        </div>
        <div style="flex-grow: 1;text-align: right;">
          <b>Rp<?= number_format($total_all,0,',','.'); ?></b>
        </div>
      </div>

      <?php if ($detail['bayar'] != NULL) : ?>
        <div style="display:flex;">
          <div style="flex-grow: 1;">
           Dibayar
          </div>
          <div style="flex-grow: 1;text-align: right;">
            <b>Rp<?= number_format($detail['bayar'],0,',','.'); ?></b>
          </div>
        </div>

        <div style="margin-bottom:5px;margin-top:5px;"></div>

        <div style="display:flex;">
          <div style="flex-grow: 1;">
           Kembalian
          </div>
          <div style="flex-grow: 1;text-align: right;">
            <?php $kembalian = $detail['bayar'] - $total_all; ?>
            <b>Rp<?= number_format($kembalian,0,',','.'); ?></b>
          </div>
        </div>
      <?php endif; ?>

      

      

      <div style="margin-bottom:5px;margin-top:5px;"></div>

      <div style="margin-bottom:5px;border-bottom: 0.5px dotted grey;"></div>

      <div style="display:flex;">
        <div style="flex-grow: 1;">
          Metode Bayar
        </div>
        <div style="flex-grow: 1;text-align: right;">
          <b><?= $detail['jenis_pembayaran']; ?></b>
        </div>
      </div>

      <div style="margin-bottom:5px;margin-top:5px;border-bottom: 0.5px dotted grey;"></div>

      <center>
        <br>
        <span><i>Jual cerita bukan drama</i></span>
        <br><br>

        Terjual pada : <br>
        <b><?= $detail['waktu_pesan']; ?></b>
      </center> 

                  

      <script>
        window.print();
      </script>

  </body>
</html>
