<?php 
// koneksi ke database
// $conn = mysqli_connect("sql105.epizy.com", "epiz_33287461", "IrbHXJGNiR4bQZ", "epiz_33287461_koelacino");
$conn = mysqli_connect("localhost", "root", "", "koelacino");


function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	};
	return $rows;
};

function upload_foto() {
    $namaFile = $_FILES['file']['name'];
    $ukuranFile = $_FILES['file']['size'];
    $error = $_FILES['file']['error'];
    $tmpName = $_FILES['file']['tmp_name'];


    $ekstensifile = explode('.', $namaFile);
    $ekstensifile = strtolower(end($ekstensifile));

    // generate nama file baru
    $namaFileBaru = uniqid();
    $namaFileBaru .= '.';
    $namaFileBaru .= $ekstensifile;
    move_uploaded_file($tmpName, 'foto/' . $namaFileBaru);

    return $namaFileBaru;
}
