<?php 

session_start();
require 'functions.php';


if (!isset($_SESSION["user"])) {
    echo "<script>
    window.location.href='login.php';
  </script>";
    exit;
}

function registrasi($data) {
    global $conn;

    // htmlspecialchars berfungsi untuk tidak menjalankan script
    $harga = htmlspecialchars($data["harga"]);
    $nama = htmlspecialchars($data["nama"]);
    $jenis = htmlspecialchars($data["jenis"]);
    $gambar = upload_foto();


    mysqli_query($conn, "INSERT INTO menu VALUES(NULl, '$nama', '$harga', '$gambar', '$jenis')");
    return mysqli_affected_rows($conn);
}

if (isset($_POST["register"])) {
  
  if (registrasi($_POST) > 0 ) {
     $success = true;
  } else {
    echo mysqli_error($conn);
  }

} 

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'link.php'; ?>
  </head>
  <body>

    <?php if (isset($success)) : ?>
      <script>
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true
        })

        Toast.fire({
          icon: 'success',
          title: 'Berhasil Menambah Menu'
        })
      </script> 
      <?php endif; ?>
    <!-- ======== sidebar-nav start =========== -->
    <?php include 'sidebar.php'; ?>
    <!-- ======== sidebar-nav end =========== -->

    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">
      <!-- ========== header start ========== -->
      <header class="header">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-5 col-md-5 col-6">
              <div class="header-left d-flex align-items-center">
                <div class="menu-toggle-btn mr-20">
                  <button
                    id="menu-toggle"
                    class="main-btn primary-btn btn-hover"
                  >
                    <i class="lni lni-chevron-left me-2"></i> Menu
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <!-- ========== header end ========== -->

      <!-- ========== tab components start ========== -->
      <section class="tab-components">
        <div class="container-fluid">
          <!-- ========== title-wrapper start ========== -->
          <div class="title-wrapper pt-30">
            <div class="row align-items-center">
              <div class="col-md-6">
                <div class="title mb-30">
                  <h2>Tambah Menu</h2>
                </div>
              </div>
              <!-- end col -->
              <div class="col-md-6">
                <div class="breadcrumb-wrapper mb-30">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a href="#0">Koelacino</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Tambah Menu
                      </li>
                    </ol>
                  </nav>
                </div>
              </div>
              <!-- end col -->
            </div>
            <!-- end row -->
          </div>
          <!-- ========== title-wrapper end ========== -->

          <!-- ========== form-elements-wrapper start ========== -->
          <div class="form-elements-wrapper">
            <div class="row">
              <div class="col">
                <!-- input style start -->
                <form action="" method="post" enctype="multipart/form-data">
                <div class="card-style mb-30">
                  <div class="input-style-1">
                    <label>Jenis Menu</label>
                    <select name="jenis" class="form-control" required>
                      <option value="Minuman">Minuman</option>
                      <option value="Makanan">Makanan</option>
                    </select>
                  </div>
                  <div class="row">
                    <div class="col">
                      <div class="input-style-1">
                        <label>Nama Menu</label>
                        <input type="text" name="nama" placeholder="Contoh: Espresso" required />
                      </div>
                    </div>
                    <div class="col">
                      <div class="input-style-1">
                        <label>Harga</label>
                        <input type="number" name="harga" placeholder="Masukkan Harga" required />
                      </div>
                    </div>
                  </div>
                  <div class="input-style-1">
                    <label>Gambar Menu</label>
                    <input type="file" name="file" required />
                  </div>
                  <button type="submit" name="register" 
                      class="
                        btn
                        primary-btn
                        btn-hover
                        w-100
                        text-center
                      "
                    >
                      Tambah
                    </button>
                  </form>
                </div>
                <!-- end card -->
                <!-- ======= input style end ======= -->



              </div>
              <!-- end col -->
            </div>
            <!-- end row -->
          </div>
          <!-- ========== form-elements-wrapper end ========== -->
        </div>
        <!-- end container -->
      </section>
      <!-- ========== tab components end ========== -->

      <!-- ========== footer start =========== -->
      <footer class="footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-6 order-last order-md-first">
              <div class="copyright text-center text-md-start">
                <p class="text-sm">
                  Designed and Developed by
                  <a
                    href="https://plainadmin.com"
                    rel="nofollow"
                    target="_blank"
                  >
                    PlainAdmin
                  </a>
                </p>
              </div>
            </div>
            <!-- end col-->
            <div class="col-md-6">
              <div
                class="
                  terms
                  d-flex
                  justify-content-center justify-content-md-end
                "
              >
                <a href="#0" class="text-sm">Term & Conditions</a>
                <a href="#0" class="text-sm ml-15">Privacy & Policy</a>
              </div>
            </div>
          </div>
          <!-- end row -->
        </div>
        <!-- end container -->
      </footer>
      <!-- ========== footer end =========== -->
    </main>
    <!-- ======== main-wrapper end =========== -->

    <!-- ========= All Javascript files linkup ======== -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/Chart.min.js"></script>
    <script src="assets/js/dynamic-pie-chart.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/fullcalendar.js"></script>
    <script src="assets/js/jvectormap.min.js"></script>
    <script src="assets/js/world-merc.js"></script>
    <script src="assets/js/polyfill.js"></script>
    <script src="assets/js/main.js"></script>
  </body>
</html>
