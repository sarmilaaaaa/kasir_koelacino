<?php 
session_start();
include 'functions.php';

if (!isset($_SESSION["user"])) {
    echo "<script>
    window.location.href='login.php';
  </script>";
    exit;
}

$zona_waktu = time() + (60 * 60 * 8); 
$tanggal_sekarang = gmdate('d', $zona_waktu); 

 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'link.php'; ?>
    <style>
      th,td {
        text-align: center !important;
      }
    </style>
  </head>
  <body>

    <?php if (isset($_GET['welcome'])) : ?>

    <?php if ($_GET['welcome'] = "true") : ?>
    <script>
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true
        })

        Toast.fire({
          icon: 'success',
          title: 'Selamat Datang!'
        })
      </script> 

    <?php endif; ?>
    <?php endif; ?>


    <!-- ======== sidebar-nav start =========== -->
    <?php include 'sidebar.php'; ?>
    <!-- ======== sidebar-nav end =========== -->

    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">
      <!-- ========== header start ========== -->
      <header class="header">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-5 col-md-5 col-6">
              <div class="header-left d-flex align-items-center">
                <div class="menu-toggle-btn mr-20">
                  <button
                    id="menu-toggle"
                    class="main-btn primary-btn btn-hover"
                  >
                    <i class="lni lni-chevron-left me-2"></i> Menu
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <!-- ========== header end ========== -->

      <!-- ========== section start ========== -->
      <section class="section">
        <div class="container-fluid">
          <!-- ========== title-wrapper start ========== -->
          <div class="title-wrapper pt-30">
            <div class="row align-items-center">
              <div class="col-md-6">
                <div class="title mb-30">
                  <h2>Koelacino Dashboard</h2>
                    <p>Anda login menggunakan username <b class="text-info"><?= $_SESSION['username']; ?></b></p>

                </div>
              </div>
              <!-- end col -->
              <div class="col-md-6">
                <div class="breadcrumb-wrapper mb-30">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a href="#0">Koelacino</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Dashboard
                      </li>
                    </ol>
                  </nav>
                </div>
              </div>
              <!-- end col -->
            </div>
            <!-- end row -->
          </div>
          <!-- ========== title-wrapper end ========== -->
          <div class="row">
            <div class="col-xl-6 col-lg-4 col-sm-6">
              <div class="icon-card mb-30">
                <div class="icon purple">
                  <i class="lni lni-cart-full"></i>
                </div>
                <div class="content">
                  <h6 class="mb-10">Total Penjualan Hari Ini</h6>
                  <h3 class="text-bold mb-10">
                    <?php $hitung_penjualan = mysqli_query($conn, "SELECT SUM(jumlah) as jml FROM pesanan WHERE status IS NOT NULL AND DAY(tanggal) = '$tanggal_sekarang'"); ?>
                    <?php foreach ($hitung_penjualan as $x) {} ?>
                    <?= $x['jml']; ?> item
                  </h3>
                </div>
              </div>
              <!-- End Icon Cart -->
            </div>
            <!-- End Col -->
            <div class="col-xl-6 col-lg-4 col-sm-6">
              <div class="icon-card mb-30">
                <div class="icon success">
                  <i class="lni lni-dollar"></i>
                </div>
                <div class="content">
                  <?php $px = query("SELECT SUM(jumlah * harga) as pendapatan FROM pesanan WHERE status IS NOT NULL")[0]; ?>
                  <h6 class="mb-10">Total Pemasukan</h6>
                  <h3 class="text-bold mb-10">Rp<?= number_format($px['pendapatan'],0,',','.'); ?></h3>
                </div>
              </div>
              <!-- End Icon Cart -->
            </div>
          </div>
        </div>
        <!-- end container -->
      </section>
      <!-- ========== section end ========== -->

      <!-- ========== footer start =========== -->
      <footer class="footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-6 order-last order-md-first">
              <div class="copyright text-center text-md-start">
                <p class="text-sm">
                  Designed and Developed by
                  <a
                    href="https://plainadmin.com"
                    rel="nofollow"
                    target="_blank"
                  >
                    PlainAdmin
                  </a>
                </p>
              </div>
            </div>
            <!-- end col-->
            <div class="col-md-6">
              <div
                class="
                  terms
                  d-flex
                  justify-content-center justify-content-md-end
                "
              >
                <a href="#0" class="text-sm">Term & Conditions</a>
                <a href="#0" class="text-sm ml-15">Privacy & Policy</a>
              </div>
            </div>
          </div>
          <!-- end row -->
        </div>
        <!-- end container -->
      </footer>
      <!-- ========== footer end =========== -->
    </main>
    <!-- ======== main-wrapper end =========== -->

    <!-- ========= All Javascript files linkup ======== -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/Chart.min.js"></script>
    <script src="assets/js/dynamic-pie-chart.js"></script>
    <script src="assets/js/moment.min.js"></script>
    <script src="assets/js/fullcalendar.js"></script>
    <script src="assets/js/jvectormap.min.js"></script>
    <script src="assets/js/world-merc.js"></script>
    <script src="assets/js/polyfill.js"></script>
    <script src="assets/js/main.js"></script>

  </body>
</html>
