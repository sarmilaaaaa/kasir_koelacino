<?php 

session_start();
require '../functions.php';

function upload() {
    $namaFile = $_FILES['file']['name'];
    $ukuranFile = $_FILES['file']['size'];
    $error = $_FILES['file']['error'];
    $tmpName = $_FILES['file']['tmp_name'];


    $ekstensifile = explode('.', $namaFile);
    $ekstensifile = strtolower(end($ekstensifile));

    // generate nama file baru
    $namaFileBaru = uniqid();
    $namaFileBaru .= '.';
    $namaFileBaru .= $ekstensifile;
    move_uploaded_file($tmpName, '../foto/' . $namaFileBaru);

    return $namaFileBaru;
}



if (!isset($_SESSION["user"])) {
    echo "<script>
    window.location.href='login.php';
  </script>";
    exit;
}

function tambah_menu($data) {
    global $conn;

    // htmlspecialchars berfungsi untuk tidak menjalankan script
    $harga = htmlspecialchars($data["harga"]);
    $nama = htmlspecialchars($data["nama"]);
    $jenis = htmlspecialchars($data["jenis"]);
    $gambar = upload();


    mysqli_query($conn, "INSERT INTO menu VALUES(NULl, '$nama', '$harga', '$gambar', '$jenis')");
    return mysqli_affected_rows($conn);
}

function edit_menu($data) {
    global $conn;

    // htmlspecialchars berfungsi untuk tidak menjalankan script
    $id = htmlspecialchars($data["id"]);
    $harga = htmlspecialchars($data["harga"]);
    $nama = htmlspecialchars($data["nama"]);
    $jenis = htmlspecialchars($data["jenis"]);
    
    // Cek image empty or not
    if(isset($_FILES['file']) && empty($_FILES['file']['name'])) { 
       mysqli_query($conn, "UPDATE menu SET jenis = '$jenis', nama = '$nama', harga = $harga WHERE id = $id");
      return mysqli_affected_rows($conn);

    } else {
      $gambar = upload();
      mysqli_query($conn, "UPDATE menu SET jenis = '$jenis', nama = '$nama', harga = $harga, gambar = '$gambar' WHERE id = $id");
      return mysqli_affected_rows($conn);
    }


   
}

if (isset($_POST["register"])) {
  
  if (tambah_menu($_POST) > 0 ) {
     $success = true;
  } else {
    echo mysqli_error($conn);
  }

} 

if (isset($_POST["editMenu"])) {
  
  if (edit_menu($_POST) > 0 ) {
     $successEdit = true;
  } else {
    echo mysqli_error($conn);
  }

} 

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include 'link.php'; ?>
    <script>
         $(document).ready(function() {

         $("#form").hide();

         $("#btn-show").click(function() {
           $("#form").show();
         })

         $("#btn-hide").click(function() {
           $("#form").hide();
         })

       });
    </script>
  </head>
  <body>

     <?php  if (isset($_GET['edit'])) : ?>

      <script type='text/javascript'>
          $(document).ready(function(){
            $('#edit<?= $_GET["id"]; ?>').modal('show');
          });

      </script>

    <?php endif; ?>


    <?php if (isset($success)) : ?>
      <script>
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true
        })

        Toast.fire({
          icon: 'success',
          title: 'Berhasil Menambah Menu'
        })
      </script> 
      <?php endif; ?>

      <?php if (isset($successEdit)) : ?>
      <script>
          window.location.href="index.php?editSuccess=true";
      </script> 
      <?php endif; ?>

      <?php if (isset($_GET['editSuccess'])) : ?>
      <script>
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true
        })

        Toast.fire({
          icon: 'success',
          title: 'Berhasil Edit Menu'
        })
      </script> 
      <?php endif; ?>

      <?php if (isset($_GET['success_hapus'])) : ?>
      <script>
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 2000,
          timerProgressBar: true
        })

        Toast.fire({
          icon: 'success',
          title: 'Berhasil Hapus Menu'
        })
      </script> 
      <?php endif; ?>
    <!-- ======== sidebar-nav start =========== -->
    <?php include 'sidebar.php'; ?>
    <!-- ======== sidebar-nav end =========== -->

    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">
      <!-- ========== header start ========== -->
      <header class="header">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-5 col-md-5 col-6">
              <div class="header-left d-flex align-items-center">
                <div class="menu-toggle-btn mr-20">
                  <button
                    id="menu-toggle"
                    class="main-btn primary-btn btn-hover"
                  >
                    <i class="lni lni-chevron-left me-2"></i> Menu
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <!-- ========== header end ========== -->

      <!-- ========== tab components start ========== -->
      <section class="tab-components">
        <div class="container-fluid">
          <!-- ========== title-wrapper start ========== -->
          <div class="title-wrapper pt-30">
            <div class="row align-items-center">
              <div class="col-md-6">
                <div class="title mb-30">
                  <h2>Kelola Menu</h2>
                </div>
              </div>
              <!-- end col -->
              <div class="col-md-6">
                <div class="breadcrumb-wrapper mb-30">
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a href="#0">Koelacino</a>
                      </li>
                      <li class="breadcrumb-item active" aria-current="page">
                        Kelola Menu
                      </li>
                    </ol>
                  </nav>
                </div>
              </div>
              <!-- end col -->
            </div>
            <!-- end row -->
            <a id="btn-show" class="btn btn-info text-white mb-3"><i class="fas fa-plus-square"></i> Tambah Menu</a>
          </div>

          <div class="my-4">
            <form action="" method="post">
              <label class="mb-3">Cari Menu : </label>
              <input type="search" name="keyword" id="keyword" autocomplete="off" placeholder="...." class="form-control">
            </form>
          </div>
          <!-- ========== title-wrapper end ========== -->

          <!-- ========== form-elements-wrapper start ========== -->
          <div class="form-elements-wrapper">
            <div class="row">
              <div class="col">
                <!-- input style start -->
                <form id="form" action="" method="post" enctype="multipart/form-data">
                <div class="card-style mb-30">
                  <p align="right">
                    <a href="#" id="btn-hide" class="btn btn-close"></a>
                  </p>
                  <div class="input-style-1">
                    <label>Jenis Menu</label>
                    <select name="jenis" class="form-control" required>
                      <option value="Minuman">Minuman</option>
                      <option value="Makanan">Makanan</option>
                    </select>
                  </div>
                  <div class="row">
                    <div class="col">
                      <div class="input-style-1">
                        <label>Nama Menu</label>
                        <input type="text" name="nama" placeholder="Contoh: Espresso" required />
                      </div>
                    </div>
                    <div class="col">
                      <div class="input-style-1">
                        <label>Harga</label>
                        <input type="number" name="harga" placeholder="Masukkan Harga" required />
                      </div>
                    </div>
                  </div>
                  <div class="input-style-1">
                    <label>Gambar Menu</label>
                    <input type="file" name="file" required />
                  </div>
                  <button type="submit" name="register" 
                      class="
                        btn
                        primary-btn
                        btn-hover
                        w-100
                        text-center
                      "
                    >
                      Tambah
                    </button>
                  </form>
                </div>
                <!-- end card -->
                <!-- ======= input style end ======= -->



              </div>
              <!-- end col -->
            </div>
            <!-- end row -->
          </div>
          <!-- ========== form-elements-wrapper end ========== -->

          <div id="ajaxMenu">
            <div class="card p-3">
              <table class="table">
                <thead>
                  <tr>
                    <th>Jenis</th>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Gambar</th>
                    <th colspan="2">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $menu = mysqli_query($conn, "SELECT * FROM menu ORDER BY id DESC"); ?>
                    <?php foreach($menu as $m) : ?>
                    <tr>
                      <td><?= $m['jenis']; ?></td>
                      <td><?= $m['nama']; ?></td>
                      <td>Rp<?= number_format($m['harga'],0,',','.'); ?></td>
                      <td><img src="../foto/<?= $m['gambar']; ?>" width="100"></td>
                      <td>
                        <button type="button" class="btn btn-warning text-white" data-bs-toggle="modal" data-bs-target="#edit<?= $m['id']; ?>">
                          <i class="fas fa-edit"></i> Edit
                        </button>
                      </td>
                      <td>
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#del<?= $m['id']; ?>">
                          <i class="fas fa-trash-alt"></i> Delete
                        </button>
                      </td>
                    </tr>
                </tbody>

                <!-- Edit Modal -->
                <div class="modal fade" id="edit<?= $m['id']; ?>" tabindex="-1" aria-labelledby="edit" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="edit">Edit Menu</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <form action="" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?= $m['id']; ?>" required>
                            <input type="hidden" name="gambar" value="<?= $m['gambar']; ?>" required>
                            <div class="mb-3">
                              <label for="nama">Nama Menu</label>
                              <input type="text" class="form-control" name="nama" value="<?= $m['nama']; ?>" required>
                            </div>

                            <div class="mb-3">
                              <label for="jenis">Jenis</label>
                              <select name="jenis" class="form-control" required>
                                <option value="<?= $m['jenis']; ?>"><?= $m['jenis']; ?></option>
                                <option value="Minuman">Minuman</option>
                                <option value="Makanan">Makanan</option>
                              </select>
                            </div>

                            <div class="mb-3">
                              <label for="harga">Harga</label>
                              <input type="number" class="form-control" name="harga" value="<?= $m['harga']; ?>" required>
                            </div>

                            <div class="mb-3">
                              <label for="nama">Gambar Baru</label>
                              <input type="file" class="form-control mb-3" name="file">
                              <div class="alert bg-warning text-white">
                                <span><i class="fas fa-info-circle"></i> Kosongkan jika tidak ingin merubah gambar</span>
                              </div>
                            </div>

                            <button type="submit" name="editMenu" class="btn btn-info w-100 text-white">Edit</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Delete Modal -->
                <div class="modal fade" id="del<?= $m['id']; ?>" tabindex="-1" aria-labelledby="del" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="del<?= $m['id']; ?>">Konfirmasi Delete Menu</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">

                        <center>
                          <p>Yakin menghapus menu secara permanen?</p>
                          <br>
                        </center>

                        <form action="" method="post" enctype="multipart/form-data">

                            <a href="hapus-menu.php?id=<?= $m['id']; ?>" class="btn btn-danger w-100 text-white">Ya, Hapus Permanen</a>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>

              <?php endforeach; ?>


              </table>
            </div>
          </div>

         

        </div>
        <!-- end container -->
      </section>
      <!-- ========== tab components end ========== -->


      

      <!-- ========== footer start =========== -->
      <footer class="footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-6 order-last order-md-first">
              <div class="copyright text-center text-md-start">
                <p class="text-sm">
                  Designed and Developed by
                  <a
                    href="https://plainadmin.com"
                    rel="nofollow"
                    target="_blank"
                  >
                    PlainAdmin
                  </a>
                </p>
              </div>
            </div>
            <!-- end col-->
            <div class="col-md-6">
              <div
                class="
                  terms
                  d-flex
                  justify-content-center justify-content-md-end
                "
              >
                <a href="#0" class="text-sm">Term & Conditions</a>
                <a href="#0" class="text-sm ml-15">Privacy & Policy</a>
              </div>
            </div>
          </div>
          <!-- end row -->
        </div>
        <!-- end container -->
      </footer>
      <!-- ========== footer end =========== -->
    </main>
    <!-- ======== main-wrapper end =========== -->

    <!-- ========= All Javascript files linkup ======== -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/Chart.min.js"></script>
    <script src="../assets/js/dynamic-pie-chart.js"></script>
    <script src="../assets/js/moment.min.js"></script>
    <script src="../assets/js/fullcalendar.js"></script>
    <script src="../assets/js/jvectormap.min.js"></script>
    <script src="../assets/js/world-merc.js"></script>
    <script src="../assets/js/polyfill.js"></script>
    <script src="../assets/js/main.js"></script>

    <script src="../ajax/index3.js"></script>
  </body>
</html>
